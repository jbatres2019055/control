"use strict"

const Employee = require("../models/employee.model");
const User = require("../models/user.model");

function addEmployee(req,res){
    var params = req.body;
    var userId = req.user.sub;
    var employee = new Employee();

    if(params.id && params.name && params.lastname && params.email && params.phone && params.position && params.department){
        employee.id = params.id;
        employee.name = params.name;
        employee.lastname = params.lastname;
        employee.email = params.email;
        employee.phone = params.phone;
        employee.position = params.position;
        employee.department = params.department;
        employee.save((err,employeeSaved)=>{
            if(err){
                return res.status(500).send({message: "Error al crear empleado"});
            }else if(employeeSaved){
                User.findByIdAndUpdate(userId, {$push: {employees: employeeSaved._id}},{new: true},(err,userUpdated)=>{
                    if(err){
                        return res.status(500).send({message: "Error al añadir empleado"});
                    }else if(userUpdated){
                        return res.send({message: "Empleado creado y agregado exitosamente", employeeSaved});
                    }else{
                        return res.status(500).send({message: "No se pudo añadir el empleado a la empresa"});
                    }
                })
            }else{
                return res.status(500).send({message: "No se creó el empleado"});
            }
        })
    }else{
        return res.send({message: "Ingrese los datos mínimos para crear un empleado"});
    }
}

function updateEmployee(req,res){
    var employeeId = req.params.id;
    var update = req.body;
    
    Employee.findByIdAndUpdate(employeeId, update,{new: true},(err,employeeUpdated)=>{
        if(err){
            return res.status(500).send({message: "Error al actualizar empleado"});
        }else if(employeeUpdated){
            return res.send({message: "Empleado actualizado", employeeUpdated});
        }else{
            return res.status(500).send({message: "Empleado inexistente"});
        }
    })
}

function removeEmployee(req,res){
    var employeeId = req.params.id;
    var userId = req.user.sub;

    User.findById(userId,(err,userFinded)=>{
        if(err){
            return res.status(500).send({message: "Error al buscar empresa"});
        }else if(userFinded){
            if(userFinded.employees.includes(employeeId)){
                User.findByIdAndUpdate(userId,{$pull: {employees: employeeId}},{new: true},(err,userUpdated)=>{
                    if(err){
                        return res.status(500).send({message: "Error al eliminar empleado de empresa"});
                    }else if(userUpdated){
                        Employee.findByIdAndRemove(employeeId,(err,employeeRemoved)=>{
                            if(err){
                                return res.status(500).send({message: "Error al eliminar empleado"});
                            }else if(employeeRemoved){
                                return res.send({message: "Empleado eliminado exitosamente", employeeRemoved});
                            }else{
                                return res.status(500).send({message: "No se eliminó el empleado"});
                            }
                        })
                    }else{
                        return res.status(500).send({message: "No se eliminó el empleado de la empresa"});
                    }
                })
            }else{
                return res.status(401).send({message: "El empleado no pertenece a esta empresa o no existe"});
            }
        }else{
            return res.status(404).send({message: "Empresa inexistente"});
        }
    })
}

function getEmployees(req,res){
    var userId = req.user.sub;

    User.findById(userId, ((err,userFinded)=>{
        if(err){
            return res.status(500).send({message: "Error al obtener empleados"});
        }else if(userFinded){
            let employees = userFinded.employees;
            return res.send({message: "Empleados ", employees});
        }else{
            return res.status(500).send({message: "No hay empleados"});
        }
    })).populate('employees')
}

module.exports = {
    addEmployee,
    updateEmployee,
    removeEmployee,
    getEmployees
}