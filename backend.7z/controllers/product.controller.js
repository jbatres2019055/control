"use strict"

const Product = require("../models/product.model");
const User = require("../models/user.model");

function addProduct(req,res){
    var params = req.body;
    var userId = req.user.sub;
    var product = new Product();

    if(params.name && params.supplier && params.stock){
        product.name = params.name;
        product.supplier = params.supplier;
        product.stock = params.stock;
        product.save((err,productSaved)=>{
            if(err){
                return res.status(500).send({message: "Error al crear producto"});
            }else if(productSaved){
                User.findByIdAndUpdate(userId, {$push: {products: productSaved._id}},{new: true},(err,userUpdated)=>{
                    if(err){
                        return res.status(500).send({message: "Error al añadir producto"});
                    }else if(userUpdated){
                        return res.send({message: "Producto creado y agregado exitosamente", productSaved});
                    }else{
                        return res.status(500).send({message: "No se pudo añadir el producto a la empresa"});
                    }
                })
            }else{
                return res.status(500).send({message: "No se creó el producto"});
            }
        })
    }else{
        return res.send({message: "Ingrese los datos mínimos para crear un producto"});
    }
}

function updateProduct(req,res){
    var productId = req.params.id;
    var update = req.body;
    
    Product.findByIdAndUpdate(productId, update,{new: true},(err,productUpdated)=>{
        if(err){
            return res.status(500).send({message: "Error al actualizar producto"});
        }else if(productUpdated){
            return res.send({message: "Producto actualizado", productUpdated});
        }else{
            return res.status(500).send({message: "Producto inexistente"});
        }
    })
}

function removeProduct(req,res){
    var productId = req.params.id;
    var userId = req.user.sub;

    User.findById(userId,(err,userFinded)=>{
        if(err){
            return res.status(500).send({message: "Error al buscar empresa"});
        }else if(userFinded){
            if(userFinded.products.includes(productId)){
                User.findByIdAndUpdate(userId,{$pull: {products: productId}},{new: true},(err,userUpdated)=>{
                    if(err){
                        return res.status(500).send({message: "Error al eliminar producto de empresa"});
                    }else if(userUpdated){
                        Product.findByIdAndRemove(productId,(err,productRemoved)=>{
                            if(err){
                                return res.status(500).send({message: "Error al eliminar producto"});
                            }else if(productRemoved){
                                return res.send({message: "Producto eliminado exitosamente"});
                            }else{
                                return res.status(500).send({message: "No se eliminó el producto"});
                            }
                        })
                    }else{
                        return res.status(500).send({message: "No se eliminó el producto de la empresa"});
                    }
                })
            }else{
                return res.status(401).send({message: "El producto no pertenece a esta empresa, no existe o ya fue eliminado"});
            }
        }else{
            return res.status(404).send({message: "Empresa inexistente"});
        }
    })
}

function getProducts(req,res){
    var userId = req.user.sub;

    User.findById(userId, ((err,userFinded)=>{
        if(err){
            return res.status(500).send({message: "Error al obtener productos"});
        }else if(userFinded){
            let products = userFinded.products;
            return res.send({message: "Productos ", products});
        }else{
            return res.status(500).send({message: "No hay productos"});
        }
    })).populate('products')
}

function buyProduct(req,res){
    let productId = req.params.id;
    var params = req.body;

    if(params.stock){
        Product.findById(productId,(err,productFinded)=>{
            if(err){
                return res.status(500).send({message: "Error al buscar producto"});
            }else if(productFinded){
                if(productFinded.stock < params.stock){
                    return res.send({message: "Cantidad de producto insuficiente para su pedido"});
                }else{
                    var stock = productFinded.stock - parseInt(params.stock);
                    var cantidad = productFinded.sales + parseInt(params.stock);
                    Product.findByIdAndUpdate(productId,{stock: stock, sales: cantidad},{new:true},(err,productUpdated)=>{
                        if(err){
                            return res.status(500).send({message: "Error al actualizar producto"});
                        }else if(productUpdated){
                            return res.send({message: "Producto adquirido exitosamente", productUpdated});
                        }else{
                            return res.status(500).send({message: "No se adquirió el producto"});
                        }
                    })
                }
            }else{
                return res.send({message: "Producto inexistente"});
            }
        })
    }else{
        return res.send({message: "Ingrese la cantidad a comprar"});
    }
}

module.exports = {
    addProduct,
    updateProduct,
    removeProduct,
    getProducts,
    buyProduct
} 