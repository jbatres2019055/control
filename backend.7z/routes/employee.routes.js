"use strict";

const express = require("express");
const employeeController = require("../controllers/employee.controller");
const mdAuth = require("../middlewares/authenticated");

var api = express.Router();

api.put("/addEmployee", [mdAuth.ensureAuth], employeeController.addEmployee);
api.put("/updateEmployee/:id", [mdAuth.ensureAuth], employeeController.updateEmployee);
api.put("/removeEmployee/:id", [mdAuth.ensureAuth], employeeController.removeEmployee);
api.get("/getEmployees", [mdAuth.ensureAuth], employeeController.getEmployees);

module.exports = api; 