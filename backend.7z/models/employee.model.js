'use strict'

var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var employeeSchema = Schema({
    id: Number,
    name: String,
    lastname: String,
    email: String,
    phone: Number,
    position: String,
    department: String
});

module.exports = mongoose.model('employee', employeeSchema);