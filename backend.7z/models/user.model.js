'use strict'

var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var userSchema = Schema({
    id: Number,
    name: String,
    username: String,
    password: String,
    email: String,
    phone: Number,
    role: {type: String, default: "ROLE_EMPRESA"},
    employees: [{type: Schema.ObjectId, ref: 'employee'}],
    products: [{type: Schema.ObjectId, ref: 'product'}]
});

module.exports = mongoose.model('user', userSchema);