export const CONNECTION ={
    URI: 'http://localhost:3200/api/'
}