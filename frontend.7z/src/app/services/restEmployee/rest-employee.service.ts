import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { CONNECTION } from '../global';

@Injectable({
  providedIn: 'root'
})
export class RestEmployeeService {

  public uri:string;
  public user:any;
  public token:any;
  public role:any;
  public username:any;

  public httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  private extractData(res: Response){
    let body = res;
    return body || [] || {};
  }

  constructor(private http: HttpClient) { 
    this.uri = CONNECTION.URI;
  }

  getToken(){
    let token = localStorage.getItem('token')!;
    this.token = token;
    
    return token;
  }

  addEmployee(user: any){
    let headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': this.getToken()
    });
    let params = JSON.stringify(user);
    return this.http.put<any>(`${this.uri}addEmployee`, params, {headers: headers}).pipe(map(this.extractData))
  }

  getEmployees(){
    let headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': this.getToken()
    });
    return this.http.get<any>(`${this.uri}getEmployees`, {headers: headers}).pipe(map(this.extractData))
  }

  updateEmployee(user: any){
    let headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': this.getToken()
    });
    let params = JSON.stringify(user);
    return this.http.put<any>(`${this.uri}updateEmployee/${user._id}`, params, {headers: headers}).pipe(map(this.extractData))
  }

  deleteEmployee(user: any){
    let headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': this.getToken()
    });
    return this.http.put<any>(`${this.uri}removeEmployee/${user._id}`,[], {headers: headers}).pipe(map(this.extractData))
  }
}
