export class Employee {
    constructor(
        public _id: string,
        public id: Number,
        public name: string,
        public lastname: string,
        public email: string,
        public phone: Number,
        public position: string,
        public department: string
    ){}
}