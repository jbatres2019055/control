import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'search'
})
export class SearchPipe implements PipeTransform {

  transform(data: any, search: any): any {
      if(search != undefined && data != undefined){
        return data.filter((d:any) =>{
          return d.name.toLowerCase().includes(search.toLowerCase());
        })
      }else{
        return data;
      }
  }

}
