import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { User } from 'src/app/models/user';
import { RestUserService } from 'src/app/services/restUser/rest-user.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.css']
})
export class CompanyComponent implements OnInit {

  user: User;
  users: Array<User> = [];
  search =  "";

  constructor(private restUser: RestUserService) { 
    this.user = new User("","","","","",0,"",[],[]);
  }

  ngOnInit(): void {
    this.restUser.getCompanys().subscribe((resp:any)=>{
      if(resp.users){
        this.users = resp.users;
        localStorage.setItem("companys",JSON.stringify(resp.users));
      }else{
        Swal.fire({
          icon: 'error',
          title: '¡Error!',
          text: resp.message
        })
      }
    },
    (error)=>{
      Swal.fire({
        icon: 'error',
        title: '¡Error!',
        text: error.error.message
      })
    })
  }

  onSubmit(companyForm: NgForm){
    let user: any = this.user;
    this.restUser.createCompany(user).subscribe((resp:any)=>{
      if(resp.userSaved){
        companyForm.reset();
        this.users.push(resp.userSaved);
        localStorage.setItem("companys",JSON.stringify(this.users));
        Swal.fire({
          icon: 'success',
          title: 'Empresa creada exitosamente'
        })
      }else{
        Swal.fire({
          icon: 'error',
          title: '¡Error!',
          text: resp.message
        })
      }
    },
    (error)=>{
      Swal.fire({
        icon: 'error',
        title: '¡Error!',
        text: error.error.message
      })
    })
  }

  updateCompany(updateCompanyForm: NgForm){
    let user: any = this.user;
    delete user.password;
    this.restUser.updateCompany(user).subscribe((resp:any)=>{
      if(resp.userUpdated){
        updateCompanyForm.reset();
        this.user = new User("","","","","",0,"",[],[]);
        Swal.fire({
          icon: 'success',
          title: 'Empresa actualizada exitosamente'
        })
        this.ngOnInit();
      }else{
        Swal.fire({
          icon: 'error',
          title: '¡Ups!',
          text: resp.message
        })
      }
    },
    (error)=>{
      Swal.fire({
        icon: 'error',
        title: '¡Ups!',
        text: error.error.message
      })
    })
  }

  deleteCompanyInfo(){
    this.user = new User("","","","","",0,"",[],[]);
  }

  setCompanyInfo(user: any){
    this.user = user;
  }

  deleteCompany(book: any){
    this.setCompanyInfo(book);
    let userToDelete:any = this.user;
    Swal.fire({
      title: "¿Eliminar empresa " + userToDelete.name + " ?" ,
      text: "Esta acción no se puede remover",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: "Sí, eliminar",
      cancelButtonText: "Cancelar",
    })
    .then(resultado => {
        if (resultado.value) {
          this.restUser.deleteCompany(this.user).subscribe((resp:any)=>{
            if(resp.userRemoved){
              Swal.fire({
                icon: 'success',
                title: 'Empresa eliminada exitosamente'
              })
              this.ngOnInit();
              this.deleteCompanyInfo();
            }else{
              Swal.fire({
                icon: 'error',
                title: '¡Ups!',
                text: resp.message
              })
            }
          },
           (error:any)=>{
            Swal.fire({
              icon: 'error',
              title: '¡Ups!',
              text: error.error.message
            })
          })
        }else {
          this.deleteCompanyInfo();
        }
    });
  }

  ngDoCheck(){
    this.users = JSON.parse(localStorage.getItem("companys")!);
  }

}
