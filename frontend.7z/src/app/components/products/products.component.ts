import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
//import { ChartOptions, ChartType } from 'chart.js';
import { Product } from 'src/app/models/product';
import { RestProductService } from 'src/app/services/restProduct/rest-product.service';
import Swal from 'sweetalert2';
//import { Label } from 'ng2-charts';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  product: Product;
  products: Array<Product> = [];
  search = "";
  type = "Ascendente";
  stock = 0;

  constructor(private restProduct: RestProductService) { 
    this.product = new Product("","",0,0,"");
  }

  ngOnInit(): void {
    this.restProduct.getProducts().subscribe((resp:any)=>{
      if(resp.products){
        this.products = resp.products;
        localStorage.setItem("products",JSON.stringify(resp.products));
      }else{
        Swal.fire({
          icon: 'error',
          title: '¡Error!',
          text: resp.message
        })
      }
    },
    (error)=>{
      Swal.fire({
        icon: 'error',
        title: '¡Error!',
        text: error.error.message
      })
    })
  }

  onSubmit(employeeForm: NgForm){
    let user: any = this.product;
    this.restProduct.addProduct(user).subscribe((resp:any)=>{
      if(resp.productSaved){
        employeeForm.reset();
        this.products.push(resp.productSaved);
        localStorage.setItem("products",JSON.stringify(this.products));
        Swal.fire({
          icon: 'success',
          title: 'Producto agregado exitosamente'
        })
      }else{
        Swal.fire({
          icon: 'error',
          title: '¡Error!',
          text: resp.message
        })
      }
    },
    (error)=>{
      Swal.fire({
        icon: 'error',
        title: '¡Error!',
        text: error.error.message
      })
    })
  }

  buyProduct(a: NgForm){
    let user: any = this.product;
    this.restProduct.buyProduct(this.stock,user._id).subscribe((resp:any)=>{
      console.log(resp);
      if(resp.productUpdated){
        a.reset();
        Swal.fire({
          icon: 'success',
          title: 'Producto adquirido exitosamente'
        })
        this.ngOnInit();
      }else{
        Swal.fire({
          icon: 'error',
          title: '¡Error!',
          text: resp.message
        })
      }
    },
    (error)=>{
      Swal.fire({
        icon: 'error',
        title: '¡Error!',
        text: error.error.message
      })
    })
  }

  deleteCompanyInfo(){
    this.product = new Product("","",0,0,"");
  }

  setCompanyInfo(user: any){
    this.product = user;
  }

  ngDoCheck(){
    this.products = JSON.parse(localStorage.getItem("products")!);
  }

  /* public pieChartOptions: ChartOptions = {
    responsive: true,
    legend: {
      position: 'top',
    },
    plugins: {
      datalabels: {
        formatter: (value:any, ctx:any) => {
          const label = ctx.chart.data.labels[ctx.dataIndex];
          return label;
        },
      },
    }
  }; */
  /* public pieChartLabels: Label[] = [];
  public pieChartData: number[] = [];
  public pieChartType: ChartType = 'pie';
  public pieChartLegend = true;
  public pieChartColors: any[] = [
    {
      backgroundColor : []
    },
  ];

  // events
  public chartClicked({ event, active }: { event: MouseEvent, active: {}[] }): void {
    console.log(event, active);
  }

  public chartHovered({ event, active }: { event: MouseEvent, active: {}[] }): void {
    console.log(event, active);
  }

  public getRandomColor(): any {
    var color = Math.floor(0x1000000 * Math.random()).toString(16);
    return '#' + ('000000' + color).slice(-6);
  } */

}
