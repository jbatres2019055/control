import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Employee } from 'src/app/models/employee';
import { RestEmployeeService } from 'src/app/services/restEmployee/rest-employee.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css']
})
export class EmployeesComponent implements OnInit {

  employee: Employee;
  employees: Array<Employee> = [];
  search =  "";

  constructor(private restEmployee: RestEmployeeService) { 
    this.employee = new Employee("",0,"","","",0,"","");
  }

  ngOnInit(): void {
    this.restEmployee.getEmployees().subscribe((resp:any)=>{
      if(resp.employees){
        this.employees = resp.employees;
        localStorage.setItem("employees",JSON.stringify(resp.employees));
      }else{
        Swal.fire({
          icon: 'error',
          title: '¡Error!',
          text: resp.message
        })
      }
    },
    (error)=>{
      Swal.fire({
        icon: 'error',
        title: '¡Error!',
        text: error.error.message
      })
    })
  }

  onSubmit(employeeForm: NgForm){
    let user: any = this.employee;
    this.restEmployee.addEmployee(user).subscribe((resp:any)=>{
      if(resp.employeeSaved){
        employeeForm.reset();
        this.employees.push(resp.employeeSaved);
        localStorage.setItem("employees",JSON.stringify(this.employees));
        Swal.fire({
          icon: 'success',
          title: 'Empleado agregado exitosamente'
        })
      }else{
        Swal.fire({
          icon: 'error',
          title: '¡Error!',
          text: resp.message
        })
      }
    },
    (error)=>{
      Swal.fire({
        icon: 'error',
        title: '¡Error!',
        text: error.error.message
      })
    })
  }

  updateEmployee(updateCompanyForm: NgForm){
    let user: any = this.employee;
    delete user.password;
    this.restEmployee.updateEmployee(user).subscribe((resp:any)=>{
      if(resp.employeeUpdated){
        updateCompanyForm.reset();
        this.employee = new Employee("",0,"","","",0,"","");
        Swal.fire({
          icon: 'success',
          title: 'Empleado actualizado exitosamente'
        })
        this.ngOnInit();
      }else{
        Swal.fire({
          icon: 'error',
          title: '¡Ups!',
          text: resp.message
        })
      }
    },
    (error)=>{
      Swal.fire({
        icon: 'error',
        title: '¡Ups!',
        text: error.error.message
      })
    })
  }

  deleteEmployeeInfo(){
    this.employee = new Employee("",0,"","","",0,"","");
  }

  setEmployeeInfo(user: any){
    this.employee = user;
  }

  deleteEmployee(employee: any){
    this.setEmployeeInfo(employee);
    let userToDelete:any = this.employee;
    Swal.fire({
      title: "¿Eliminar empleado " + userToDelete.name + " ?" ,
      text: "Esta acción no se puede remover",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: "Sí, eliminar",
      cancelButtonText: "Cancelar",
    })
    .then(resultado => {
        if (resultado.value) {
          this.restEmployee.deleteEmployee(this.employee).subscribe((resp:any)=>{
            if(resp.employeeRemoved){
              Swal.fire({
                icon: 'success',
                title: 'Empleado eliminado exitosamente'
              })
              this.ngOnInit();
              this.deleteEmployeeInfo();
            }else{
              Swal.fire({
                icon: 'error',
                title: '¡Ups!',
                text: resp.message
              })
            }
          },
           (error:any)=>{
            Swal.fire({
              icon: 'error',
              title: '¡Ups!',
              text: error.error.message
            })
          })
        }else {
          this.deleteEmployeeInfo();
        }
    });
  }

  ngDoCheck(){
    this.employees = JSON.parse(localStorage.getItem("employees")!);
  }

}
